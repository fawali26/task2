import csv

#from pydantic_core._pydantic_core import ValidationError

from models import Student

def load_students_from_csv(file_path):
    students = []

    try:
        with open(file_path, newline='') as file:
            reader = csv.DictReader(file)
            next(reader)
            for row in reader:
                students.append(Student.from_csv_row(row))
    except FileNotFoundError:
        print('File not found')
    except Exception as e:
        print("Error loading file",e)
    return students

def save_students_to_csv(file_path,students):
    try:
        with open(file_path,'w',newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Name","ID","Grade1","Grade2","Grade3"])
            for student in students:
                writer.writerow([student.name,student.id]+student.grades)
    except Exception as e:
        print("Error saving file",e)

def validata_number_input(value):
    try:
        number = int(value)
        return number
    except ValueError:
        return ('Please enter a valid number.')


