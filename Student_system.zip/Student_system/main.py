from models import Student, Classroom
from analytics import *
from utils import *


import csv

class Student:
    def __init__(self, name, student_id, grades):
        self.name = name
        self.student_id = student_id
        self.grades = grades

    def calculate_average(self):
        return sum(self.grades) / len(self.grades)

    def grade_category(self):
        avg = self.calculate_average()
        if avg >= 90:
            return "A"
        elif avg >= 80:
            return "B"
        elif avg >= 70:
            return "C"
        elif avg >= 60:
            return "D"
        else:
            return "F"

    @staticmethod
    def validate_grade(grade):
        return 0 <= grade <= 100


class Classroom:
    def __init__(self):
        self.students = []

    def add_student(self, student):
        self.students.append(student)

    def remove_student(self, student_id):
        self.students = [s for s in self.students if s.student_id != student_id]

    def find_student(self, student_id):
        for s in self.students:
            if s.student_id == student_id:
                return s
        return None

    def class_average(self):
        if not self.students:
            return 0
        return sum(s.calculate_average() for s in self.students) / len(self.students)



def validata_number_input(value):
    try:
        return int(value)
    except ValueError:
        raise ValueError("يجب إدخال رقم صحيح.")


def load_students_from_csv(filename):
    students = []
    try:
        with open(filename, mode="r", newline="") as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                name, student_id, grades_str = row
                grades = list(map(int, grades_str.split(",")))
                students.append(Student(name, student_id, grades))
    except FileNotFoundError:
        pass
    return students


def save_students_to_csv(filename, students):
    with open(filename, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Name", "ID", "Grades"])
        for s in students:
            writer.writerow([s.name, s.student_id, ",".join(map(str, s.grades))])


def top_student(students):
    if not students:
        return None
    return max(students, key=lambda s: s.calculate_average())


def lowest_student(students):
    if not students:
        return None
    return min(students, key=lambda s: s.calculate_average())


def rank_student(students):
    return sorted(students, key=lambda s: s.calculate_average(), reverse=True)


def grade_distri(students):
    distribution = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
    for s in students:
        distribution[s.grade_category()] += 1
    return distribution

def display_menu():
    print("\n===== Student System =====")
    print("1. Add Student")
    print("2. Remove Student")
    print("3. Search Student")
    print("4. Show Top Student")
    print("5. Show Lowest Student")
    print("6. Rank Students")
    print("7. Grade Distribution")
    print("8. Class Average")
    print("9. Save & Exit")


def main():
    classroom = Classroom()
    students = load_students_from_csv("data.csv")

    for student in students:
        classroom.add_student(student)

    while True:
        display_menu()
        choice = input("Choose option: ")

        try:
            if choice == "1":
                name = input("Student Name: ")
                student_id = input("Student ID: ")

                grades = []
                for i in range(3):
                    grade = validata_number_input(input(f"Grade {i+1}: "))
                    if not Student.validate_grade(grade):
                        raise ValueError("Grade must be 0-100.")
                    grades.append(grade)

                student = Student(name, student_id, grades)
                classroom.add_student(student)
                print("Student added.")

            elif choice == "2":
                student_id = input("Enter Student ID: ")
                classroom.remove_student(student_id)
                print("Student removed.")

            elif choice == "3":
                student_id = input("Enter Student ID: ")
                student = classroom.find_student(student_id)

                if student:
                    print("Student Name:", student.name)
                    print("Student Calculate_Average:", student.calculate_average())
                    print("Student Grade_Category:", student.grade_category())

                else:
                    print("Student not found.")

            elif choice == "4":
                student = top_student(classroom.students)
                if student:
                    print(" TOP Student Name:", student.name)
                else:
                    print("No students.")

            elif choice == "5":
                student = lowest_student(classroom.students)
                if student:
                    print("Lowest Student Name:", student.name)
                else:
                    print("No students.")
            elif choice == "6":
                ranked = rank_student(classroom.students)
                for s in ranked:
                    print("Student Name:", s.name, '&&&',"Student Average:", s.calculate_average())

            elif choice == "7":
                print(grade_distri(classroom.students))

            elif choice == "8":
                print("Class Average:", classroom.class_average())

            elif choice == "9":
                save_students_to_csv("data.csv", classroom.students)
                print("Saved. Goodbye.")
                break

            else:
                print("Invalid option.")

        except Exception as e:
            print("Error:", e)


if __name__ == "__main__":
    main()