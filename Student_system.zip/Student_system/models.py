class Student:
    _id_counter = 1000

    def __init__(self, name, student_id=None, grades=[]):
        self._name = name
        self._grades = grades
        self._student_id = student_id if student_id else Student._generate_id()

    @classmethod
    def _generate_id(cls):
        cls._id_counter += 1
        return cls._id_counter

    @property
    def name(self):
        return self._name

    @property
    def student_id(self):
        return self._student_id

    @property
    def grades(self):
        return self._grades

    def average(self):
        if not self._grades:
            return 0
        return sum(self._grades) / len(self._grades)

    def grade(self):
        avg = self.average()
        if avg >= 90:
            return "A"
        elif avg >= 80:
            return "B"
        elif avg >= 70:
            return "C"
        elif avg >= 60:
            return "D"
        else:
            return "F"

    @staticmethod
    def validate_grade(grade):
        return 0 <= grade <= 100

    @classmethod
    def from_csv_row(cls, row):
        _name = row[0]
        student_id = int(row[1])
        grades = list(map(int, row[2:]))
        return cls(_name, student_id, grades)


class Classroom:
    def __init__(self, name="Default Class"):
        self._name = name
        self._students = []

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        if not value:
            raise ValueError("Name cannot be empty")
        self._name = value

    @property
    def students(self):
        return self._students

    @students.setter
    def students(self, value):
        self._students = value

    def find_student(self, student_id):
        for student in self._students:
            if student.student_id == student_id:
                return student
        return None

    def add_student(self, student):
        if self.find_student(student.student_id):
            raise ValueError("Student ID already exists.")
        self._students.append(student)

    def remove_student(self, student_id):
        student = self.find_student(student_id)
        if not student:
            raise ValueError("Student not found.")
        self._students.remove(student)

    def class_average(self):
        if not self._students:
            return 0
        return sum(student.average() for student in self._students) / len(self._students)