def top_student(students):
    return max(students,key=lambda s:s.avarage(),default=None)

def lowest_student(students):
    return min(students,key=lambda s:s.avarage(),default=None)

def rank_student(students):
    return sorted(students,key=lambda s:s.avarage(),reverse=True)

def grade_distri(students):
    distri={"A":0,"B":0,"C":0,"D":0,"F":0}
    for student in students:
        category=student.grade()
        distri[category]+=1
    return distri