import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
articles = [
    "Data analysis helps organizations make accurate decisions and improve overall performance",
    "Data analysis enables organizations to make better decisions and enhance performance",
    "Collecting and analyzing data supports strategic decisions and improves organizational performance",
    "Organizations rely on data analysis to improve decisions and overall efficiency",
    "Accurate data analysis strengthens decision making and enhances business performance",
    "Continuous data analysis improves decision quality and organizational effectiveness",
    "Organizations use data analysis to support decisions and optimize performance",
    "Effective data collection and analysis improve decision processes and results",
    "Business performance increases through consistent data analysis and informed decisions",
    "Strategic decisions depend on accurate data analysis and performance evaluation",
    "Data driven organizations improve performance through careful analysis and decisions",
    "Analytical data processes enhance decision making and organizational outcomes",
    "Organizations achieve better results using structured data analysis and evaluation",
    "Data analysis provides insights that strengthen decisions and performance",
    "Strong organizational performance requires reliable data analysis and decision support"
]
processed_articles = [article.lower().split() for article in articles]
vocabulary = sorted(set(word for article in processed_articles for word in article))

print(f" Total unique words: {len(vocabulary)}")
binary_matrix = []

for article in processed_articles:
    vector = [1 if word in article else 0 for word in vocabulary]
    binary_matrix.append(vector)

binary_matrix = np.array(binary_matrix)
print(f"Binary Matrix shape: {binary_matrix.shape}")
similarity_matrix = cosine_similarity(binary_matrix)

print("📈 Cosine Similarity Matrix:")
print(np.round(similarity_matrix, 2))